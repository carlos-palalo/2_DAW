<?php
echo "<script>alert('Carlos Palacios Alonso - 1º DAW');</script>";
echo "<script>window.location='menu.php';</script>";